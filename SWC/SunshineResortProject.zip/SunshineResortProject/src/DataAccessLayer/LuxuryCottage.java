package DataAccessLayer;

public class LuxuryCottage extends Cottage {
	private int noOfBeds;
	private double cottagePrice;
	
	public LuxuryCottage(int cottageNo, String cottageAddress,
			String cottageStatus, boolean isLuxuryCottage, int noOfBeds, double cottagePrice) {
		super(cottageNo, cottageAddress, cottageStatus, isLuxuryCottage);
		this.noOfBeds = noOfBeds;
		this.cottagePrice = cottagePrice;
	}
	
	public LuxuryCottage(String cottageAddress,
			String cottageStatus,int noOfBeds, double cottagePrice) {
		super(cottageAddress, cottageStatus);
		this.noOfBeds = noOfBeds;
		this.cottagePrice = cottagePrice;
	}

	public int getNoOfBeds() {
		return noOfBeds;
	}

	public void setNoOfBeds(int noOfBeds) {
		this.noOfBeds = noOfBeds;
	}

	public double getCottagePrice() {
		return cottagePrice;
	}

	public void setCottagePrice(double cottagePrice) {
		this.cottagePrice = cottagePrice;
	}
	
	public void calculatePricePerCottage(String season) {
		if(season == "high"){
			if (getNoOfBeds() == 4){
				setCottagePrice(1000 * 1.4);
			}	

		else if (getNoOfBeds() == 6) {
			setCottagePrice(1200* 1.4);
			}	
		else if (getNoOfBeds() == 8) {
			setCottagePrice(1400* 1.4);
			}
			else if (getNoOfBeds() == 12) {
			setCottagePrice(1900* 1.4);
			}
		}
	}

	@Override
	public String toString() {
		return "LuxuryCottage [noOfBeds=" + noOfBeds + ", cottagePrice="
				+ cottagePrice + ", isLuxuryCottage=" + isLuxuryCottage + "]";
	}
	
	
}
