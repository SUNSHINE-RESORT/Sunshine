package DataAccessLayer;

public class StandardCottage extends Cottage{
	private int noOfBeds;
	private double cottagePrice;
	
	

	public StandardCottage() {}


	public StandardCottage(int cottageNo, String cottageAddress,
			String cottageStatus, boolean isLuxuryCottage, int noOfBeds, double cottagePrice) {
		super(cottageNo, cottageAddress, cottageStatus, isLuxuryCottage);
		this.noOfBeds = noOfBeds;
		this.cottagePrice = cottagePrice;
	}
	
	public StandardCottage(String cottageAddress,
			String cottageStatus,int noOfBeds, double cottagePrice) {
		super(cottageAddress, cottageStatus);
		this.noOfBeds = noOfBeds;
		this.cottagePrice = cottagePrice;
	}
	
	public int getNoOfBeds() {
		return noOfBeds;
	}
	public void setNoOfBeds(int noOfBeds) {
		this.noOfBeds = noOfBeds;
	}
	public double getCottagePrice() {
		return cottagePrice;
	}
	public void setCottagePrice(double cottagePrice) {
		this.cottagePrice = cottagePrice;
	}

	public void calculatePricePerCottage() {
		if (getNoOfBeds() == 4) {
			setCottagePrice(700);
		} else if (getNoOfBeds() == 6) {
			setCottagePrice(900);
		} else if (getNoOfBeds() == 8) {
			setCottagePrice(1100);
		} else if (getNoOfBeds() == 12) {
			setCottagePrice(1500);
		}
	}
	
	@Override
	public String toString() {
		return "StandardCottage [noOfBeds=" + noOfBeds + ", cottagePrice="
				+ cottagePrice + ", isLuxuryCottage=" + isLuxuryCottage + "]";
	}


	
}
