package DataAccessLayer;

public class RentCottage {
	
	private String rentNo;
	private Customer customer;
	private Cottage cottage;
	private String dateFrom;
	private String dateTo;
	
}
