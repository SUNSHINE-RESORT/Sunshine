

package DataAccessLayer;

public class PrivateCompany extends Customer{
	// with 10% discount
	
}
