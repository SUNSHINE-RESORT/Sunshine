package DataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class CottageOperation {

	ArrayList<Cottage> cottageList = new ArrayList<Cottage>();

	Connection conn = null;
	PreparedStatement preparedStatement = null;
	ResultSet result = null;

	public CottageOperation() {
		try {
			conn = DriverManager
					.getConnection("jdbc:mysql://localhost/hotel?user=root&password=2602");
		}

		catch (SQLException e) {
			System.err.println(e);

		}
	}

}