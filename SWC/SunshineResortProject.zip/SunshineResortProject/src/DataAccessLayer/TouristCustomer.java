package DataAccessLayer;

public class TouristCustomer extends Customer{

}
