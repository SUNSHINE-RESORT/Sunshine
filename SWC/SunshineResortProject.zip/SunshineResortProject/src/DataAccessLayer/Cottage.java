package DataAccessLayer;

public class Cottage {
	private int cottageNo;
	private String cottageAddress;
	private String cottageStatus;
	private boolean isStandard;
	public boolean isLuxuryCottage;

	public Cottage() {
	}

	public Cottage(int cottageNo, String cottageAddress, String cottageStatus,
			boolean isLuxuryCottage) {
		super();
		this.cottageNo = cottageNo;
		this.cottageAddress = cottageAddress;
		this.cottageStatus = cottageStatus;
		this.isLuxuryCottage = isLuxuryCottage;

	}

	public Cottage(String cottageAddress, String cottageStatus) {
		super();
		this.cottageAddress = cottageAddress;
		this.cottageStatus = cottageStatus;


	}

	public int getCottageNo() {
		return cottageNo;
	}

	public void setCottageNo(int cottageNo) {
		this.cottageNo = cottageNo;
	}

	public String getCottageAddress() {
		return cottageAddress;
	}

	public void setCottageAddress(String cottageAddress) {
		this.cottageAddress = cottageAddress;
	}

	public String getCottageStatus() {
		return cottageStatus;
	}

	public void setCottageStatus(String cottageStatus) {
		if(this.cottageStatus == "under Renovation"){
			System.out.println("under Renovation");
		}else if(this.cottageStatus == "rented"){
			System.out.println("rented");
		}else{
			System.out.println(" ");
		}
	}

	public boolean isLuxuryCottage() {
		return isLuxuryCottage;
	}

	public void setLuxuryCottage(boolean isLuxuryCottage) {
		this.isLuxuryCottage = isLuxuryCottage;
	}


	public boolean isStandard() {
		return isStandard;
	}

	public void setStandard(boolean isStandard) {
		this.isStandard = isStandard;
	}

	@Override
	public String toString() {
		return "Cottage [cottageNo=" + cottageNo + ", cottageAddress="
				+ cottageAddress + ", cottageStatus=" + cottageStatus
				+ ", isStandard=" + isStandard + ", isLuxuryCottage="
				+ isLuxuryCottage + "]";
	}

}
