package DataAccessLayer;

public class Customer {
	private int customerNo;
	private String name;
	private String phone;
	private String email;
	
	
	public Customer(){}
	
	public Customer(int customerNo, String name, String phone, String email) {
		super();
		this.customerNo = customerNo;
		this.name = name;
		this.phone = phone;
		this.email = email;
	}

	public int getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(int customerNo) {
		this.customerNo = customerNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Customer [customerNo=" + customerNo + ", name=" + name
				+ ", phone=" + phone + ", email=" + email + "]";
	}
	
	
	
}
