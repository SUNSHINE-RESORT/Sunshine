package PresentationLayer;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import DataAccessLayer.Cottage;
import DataAccessLayer.CottageOperation;

public class CottageGui implements ActionListener {

	JFrame frame = new JFrame("Register Cottage");
	CottageOperation co = new CottageOperation();
	private ArrayList<Cottage> cottage = new ArrayList<Cottage>();

	JLabel cottageAddress = new JLabel("Cottage Address");
	JLabel cottageType = new JLabel("Cottage Type");
	JLabel noOfBeds = new JLabel("Number of beds");
	JLabel cottagePrice = new JLabel("Cottage Price");
	JLabel cottageStatus = new JLabel("Cottage Status");

	JTextField cottageAddressField = new JTextField(8);
	JTextField cottageTypesField = new JTextField(8);
	JTextField noOfBedsField = new JTextField(8);
	JTextField cottagePriceField = new JTextField(8);
	JTextField cottageStatusField = new JTextField(8);

	JButton save = new JButton("Save");
	JButton cancel = new JButton("Cancel");
	JButton clear = new JButton("Clear");
	JButton print = new JButton("Print");

	public CottageGui() {
		frame.setSize(400, 250);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE); // destroys
																// frame so the
																// program
																// doesn't
																// finish

		frame.setLayout(new BorderLayout());

		JPanel west = new JPanel(new GridLayout(4, 1));
		west.add(cottageAddress);
		west.add(cottageType);
		west.add(noOfBeds);
		west.add(cottagePrice);
		west.add(cottageStatus);

		frame.add(west, BorderLayout.WEST);
		cancel.addActionListener(this);
		save.addActionListener(this);
		clear.addActionListener(this);
		print.addActionListener(this);
		JPanel center = new JPanel(new GridLayout(4, 1));

		center.add(cottageAddressField);
		center.add(cottageTypesField);
		center.add(noOfBedsField);
		center.add(cottagePriceField);
		center.add(cottageStatusField);

		frame.add(center, BorderLayout.CENTER);

		JPanel south = new JPanel(new GridLayout(1, 4));
		south.add(new JLabel());

		south.add(save);
		south.add(cancel);
		south.add(clear);
		south.add(print);

		frame.add(south, BorderLayout.SOUTH);

		frame.setVisible(true);

	}

	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == cancel) {
			frame.dispose();
		}

		if (event.getSource() == save) {
	/*		Cottage newCottage = new Cottage(cottageAddressField.getText(),
					cottageTypesField.getText(), Integer.parseInt(noOfBedsField
							.getText()), Double.parseDouble(cottagePriceField
							.getText()), cottageStatusField.getText());
			cottage.add(newCottage);*/

			cottageAddressField.setText("");
			cottageTypesField.setText("");
			noOfBedsField.setText("");
			cottagePriceField.setText("");
			cottageStatusField.setText("");

		}

		if (event.getSource() == clear) // resets text fields
		{

			cottageAddressField.setText("");
			cottageTypesField.setText("");
			noOfBedsField.setText("");
			cottagePriceField.setText("");
			cottageStatusField.setText("");

		}

		if (event.getSource() == print) // testing method, prints to console
		{
			for (Cottage cottages : cottage) {
				System.out.println(cottages);
			}

			// alist.addGuestListToDB(guest);
		}
	}
}
